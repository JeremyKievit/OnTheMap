//
//  StudentLocations.swift
//  OnTheMap
//
//  Created by admin on 11/13/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import MapKit

struct StudentLocations {
    let coordinate: CLLocationCoordinate2D
    let title: String
    let subtitle: String
    
//if converting coordinate property to latitude/longitude (Float), remove CLLocationCoordinate2D and MapKit framework from simplifyResponse func (OTMClient), and implement logic at pin creation (streamlines code by removing UI frameworks from the model)
}
