//
//  PostLocationVC.swift
//  OnTheMap
//
//  Created by admin on 11/19/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import UIKit
import MapKit

class PostLocationVC: UIViewController {
    
    @IBOutlet weak var mapView: MKMapView!
    var locationResponse: String! // Connected to linkField in previous VC
    var linkResponse: String!
    var coordinate: CLLocationCoordinate2D?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        findLocation()
    }

    
    func findLocation() {
        guard let location = locationResponse else {
            return
        }
        
        CLGeocoder().geocodeAddressString(location) { (placemark, error) in
            guard error == nil else {
                return
            }
            
            Data.User.mapString = location
            self.coordinate = placemark!.first!.location!.coordinate
            self.setPinData(coordinate: self.coordinate!)
            Data.User.latitude = (placemark?.first?.location?.coordinate.latitude)!
            Data.User.longitude = (placemark?.first?.location?.coordinate.longitude)!
        }
    }
    
    func setPinData(coordinate: CLLocationCoordinate2D) {
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = Data.User.mapString
        
        let region = MKCoordinateRegion(center: coordinate, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        DispatchQueue.main.async {
            self.mapView.addAnnotation(annotation)
            self.mapView.setRegion(region, animated: true)
            self.mapView.regionThatFits(region)
        }
    }
    
    
    @IBAction func cancelPin(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func confirmPin(_ sender: Any) {
//            OTMClient.createStudentLocation(completion: handleCreateLocationResponse(success:error:))
    }
}

