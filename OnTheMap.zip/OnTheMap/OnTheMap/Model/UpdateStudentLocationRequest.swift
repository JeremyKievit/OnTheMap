//
//  UpdateStudentLocationRequest.swift
//  OnTheMap
//
//  Created by admin on 11/14/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation

struct UpdateStudentLocationRequest: Codable {
    let updatedAt: String
}
