//
//  MKPointAnotations.swift
//  OnTheMap
//
//  Created by admin on 11/17/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation

struct PinData: Codable {
    let createdAt: String
    let firstName: String
    let lastName: String
    let latitude: Double
    let longitude: Double
    let mapString: String
    let mediaURL: String
    let objectId: String
    let uniqueKey: String?
    let updatedAt: String
}

