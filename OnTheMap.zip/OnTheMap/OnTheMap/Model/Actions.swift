//
//  Actions.swift
//  OnTheMap
//
//  Created by admin on 11/17/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation
import MapKit

struct Actions {
    func count(input: [MKPointAnnotation]) -> Int {
        return input.count
    }
    
    func addAnnotations(input: [MKPointAnnotation]) {
        DispatchQueue.main.async {
            self.mapView.addAnnotations(pinData)
        }
    }
}

