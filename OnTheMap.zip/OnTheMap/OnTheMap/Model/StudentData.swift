//
//  StudentData.swift
//  OnTheMap
//
//  Created by admin on 11/15/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

struct StudentData: Codable {
    let uniqueKey: Int?
    let firstName: String
    let lastName: String
    let mapString: String
    let mediaURL: String
    let latitude: Float
    let longitude: Float
}
