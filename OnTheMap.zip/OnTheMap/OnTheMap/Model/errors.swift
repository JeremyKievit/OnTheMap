
//2020-11-22 16:26:37.519001-0800 OnTheMap[60037:5513265] [Storyboard] Unknown class LoginVC in Interface Builder file.
//2020-11-22 16:26:37.546328-0800 OnTheMap[60037:5513265] *** Terminating app due to uncaught exception 'NSUnknownKeyException', reason: '[<UIViewController 0x7fa49ad0b750> setValue:forUndefinedKey:]: this class is not key value coding-compliant for the key emailField.'
//*** First throw call stack:
//(
//    0   CoreFoundation                      0x00000001096eb27e __exceptionPreprocess + 350
//    1   libobjc.A.dylib                     0x0000000109558b20 objc_exception_throw + 48
//    2   CoreFoundation                      0x00000001096eae49 -[NSException raise] + 9
//    3   Foundation                          0x0000000108fa9ee3 -[NSObject(NSKeyValueCoding) setValue:forKey:] + 325
//    4   UIKitCore                           0x00000001174647c5 -[UIViewController setValue:forKey:] + 87
//    5   UIKitCore                           0x0000000117755312 -[UIRuntimeOutletConnection connect] + 109
//    6   CoreFoundation                      0x00000001096d72a2 -[NSArray makeObjectsPerformSelector:] + 242
//    7   UIKitCore                           0x00000001177524ba -[UINib instantiateWithOwner:options:] + 2190
//    8   UIKitCore                           0x000000011746bca6 -[UIViewController _loadViewFromNibNamed:bundle:] + 395
//    9   UIKitCore                           0x000000011746c7cb -[UIViewController loadView] + 177
//    10  UIKitCore                           0x000000011746caca -[UIViewController loadViewIfRequired] + 172
//    11  UIKitCore                           0x000000011746d277 -[UIViewController view] + 27
//    12  UIKitCore                           0x0000000117b233cf -[UIWindow addRootViewControllerViewIfPossible] + 150
//    13  UIKitCore                           0x0000000117b22ac0 -[UIWindow _updateLayerOrderingAndSetLayerHidden:actionBlock:] + 232
//    14  UIKitCore                           0x0000000117b23b43 -[UIWindow _setHidden:forced:] + 362
//    15  UIKit                               0x000000012e673314 -[UIWindowAccessibility _orderFrontWithoutMakingKey] + 84
//    16  UIKitCore                           0x0000000117b36ef1 -[UIWindow _mainQueue_makeKeyAndVisible] + 42
//    17  UIKitCore                           0x0000000117d42431 -[UIWindowScene _makeKeyAndVisibleIfNeeded] + 202
//    18  UIKitCore                           0x0000000117076445 +[UIScene _sceneForFBSScene:create:withSession:connectionOptions:] + 1405
//    19  UIKitCore                           0x0000000117ae8170 -[UIApplication _connectUISceneFromFBSScene:transitionContext:] + 1018
//    20  UIKitCore                           0x0000000117ae84b2 -[UIApplication workspace:didCreateScene:withTransitionContext:completion:] + 304
//    21  UIKitCore                           0x00000001176537f5 -[UIApplicationSceneClientAgent scene:didInitializeWithEvent:completion:] + 361
//    22  FrontBoardServices                  0x00000001123b6165 -[FBSSceneImpl _callOutQueue_agent_didCreateWithTransitionContext:completion:] + 442
//    23  FrontBoardServices                  0x00000001123dc4d8 __86-[FBSWorkspaceScenesClient sceneID:createWithParameters:transitionContext:completion:]_block_invoke.154 + 102
//    24  FrontBoardServices                  0x00000001123c0c45 -[FBSWorkspace _calloutQueue_executeCalloutFromSource:withBlock:] + 220
//    25  FrontBoardServices                  0x00000001123dc169 __86-[FBSWorkspaceScenesClient sceneID:createWithParameters:transitionContext:completion:]_block_invoke + 355
//    26  libdispatch.dylib                   0x000000010bfa2d48 _dispatch_client_callout + 8
//    27  libdispatch.dylib                   0x000000010bfa5cb9 _dispatch_block_invoke_direct + 300
//    28  FrontBoardServices                  0x000000011240237e __FBSSERIALQUEUE_IS_CALLING_OUT_TO_A_BLOCK__ + 30
//    29  FrontBoardServices                  0x000000011240206c -[FBSSerialQueue _queue_performNextIfPossible] + 441
//    30  FrontBoardServices                  0x000000011240257b -[FBSSerialQueue _performNextFromRunLoopSource] + 22
//    31  CoreFoundation                      0x000000010964e471 __CFRUNLOOP_IS_CALLING_OUT_TO_A_SOURCE0_PERFORM_FUNCTION__ + 17
//    32  CoreFoundation                      0x000000010964e39c __CFRunLoopDoSource0 + 76
//    33  CoreFoundation                      0x000000010964dbcc __CFRunLoopDoSources0 + 268
//    34  CoreFoundation                      0x000000010964887f __CFRunLoopRun + 1263
//    35  CoreFoundation                      0x0000000109648066 CFRunLoopRunSpecific + 438
//    36  GraphicsServices                    0x000000010f6bfbb0 GSEventRunModal + 65
//    37  UIKitCore                           0x0000000117aebd4d UIApplicationMain + 1621
//    38  OnTheMap                            0x0000000108bcf58b main + 75
//    39  libdyld.dylib                       0x000000010c02ac25 start + 1
//    40  ???                                 0x0000000000000001 0x0 + 1
//)
//libc++abi.dylib: terminating with uncaught exception of type NSException
//(lldb)


//(lldb) bt
//* thread #1, queue = 'com.apple.main-thread', stop reason = signal SIGABRT
//    frame #0: 0x000000010c4cb7fa libsystem_kernel.dylib`__pthread_kill + 10
//    frame #1: 0x000000010c528bc1 libsystem_pthread.dylib`pthread_kill + 432
//    frame #2: 0x000000010c257a5c libsystem_c.dylib`abort + 120
//    frame #3: 0x000000010be607f8 libc++abi.dylib`abort_message + 231
//    frame #4: 0x000000010be609c7 libc++abi.dylib`demangling_terminate_handler() + 262
//    frame #5: 0x0000000109558d7c libobjc.A.dylib`_objc_terminate() + 96
//    frame #6: 0x000000010be6de97 libc++abi.dylib`std::__terminate(void (*)()) + 8
//    frame #7: 0x000000010be6de39 libc++abi.dylib`std::terminate() + 41
//    frame #8: 0x0000000109558d1c libobjc.A.dylib`objc_terminate + 9
//    frame #9: 0x000000010bfa2d5c libdispatch.dylib`_dispatch_client_callout + 28
//    frame #10: 0x000000010bfa5cb9 libdispatch.dylib`_dispatch_block_invoke_direct + 300
//    frame #11: 0x000000011240237e FrontBoardServices`__FBSSERIALQUEUE_IS_CALLING_OUT_TO_A_BLOCK__ + 30
//    frame #12: 0x000000011240206c FrontBoardServices`-[FBSSerialQueue _queue_performNextIfPossible] + 441
//    frame #13: 0x000000011240257b FrontBoardServices`-[FBSSerialQueue _performNextFromRunLoopSource] + 22
//    frame #14: 0x000000010964e471 CoreFoundation`__CFRUNLOOP_IS_CALLING_OUT_TO_A_SOURCE0_PERFORM_FUNCTION__ + 17
//    frame #15: 0x000000010964e39c CoreFoundation`__CFRunLoopDoSource0 + 76
//    frame #16: 0x000000010964dbcc CoreFoundation`__CFRunLoopDoSources0 + 268
//    frame #17: 0x000000010964887f CoreFoundation`__CFRunLoopRun + 1263
//    frame #18: 0x0000000109648066 CoreFoundation`CFRunLoopRunSpecific + 438
//    frame #19: 0x000000010f6bfbb0 GraphicsServices`GSEventRunModal + 65
//    frame #20: 0x0000000117aebd4d UIKitCore`UIApplicationMain + 1621
//  * frame #21: 0x0000000108bcf58b OnTheMap`main at AppDelegate.swift:12:7
//    frame #22: 0x000000010c02ac25 libdyld.dylib`start + 1
//(lldb)
