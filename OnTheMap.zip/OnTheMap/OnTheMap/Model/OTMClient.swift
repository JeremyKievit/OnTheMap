//
//  OTMClient.swift
//  OnTheMap
//
//  Created by admin on 11/13/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation
import MapKit


class OTMClient {
    
    enum Endpoints {
        static let userDataBase = "https://onthemap-api.udacity.com/v1/users"
        static let sessionBase = "https://onthemap-api.udacity.com/v1/session"
        static let studentLocationBase = "https://onthemap-api.udacity.com/v1/StudentLocation"

        case getStudentsLocations(Int, String)
        case getPublicUserData(String)
        case login
        case logout
        case createStudentLocation
        case updateStudentLocation(String)

        var stringValue: String {
            switch self {
            case .getStudentsLocations(let limit, let order):
                return Endpoints.studentLocationBase + "?limit=\(limit)&order=\(order)"
            case .getPublicUserData(let userId):
                return Endpoints.userDataBase + "/\(userId)"
            case .login:
                return Endpoints.sessionBase
            case .logout:
                return Endpoints.sessionBase
            case .createStudentLocation:
                return Endpoints.studentLocationBase
            case .updateStudentLocation(let objectId):
                return Endpoints.studentLocationBase + "/\(objectId)"
            }
        }
        
        var url: URL {
            return URL(string: stringValue)!
        }
    }
    
    //MARK: GET Requests

    class func getStudentLocations(limit: Int = 100, order: String = "-updatedAt", completion: @escaping (_ data: [PinData]?, _ error: Error?) -> Void) {
            let request = URLRequest(url: Endpoints.getStudentsLocations(limit, order).url)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
           guard let data = data else {
               completion(nil, error)
               return
           }
           let decoder = JSONDecoder()
           do {
            let responseObject = try decoder.decode(PinData.self, from: data)
            completion([responseObject], nil)
           } catch {
               completion(nil, error)
           }
        }
       task.resume()
    }
    
    class func getPublicUserData(userId: String, completion: @escaping (UserData?, Error?) -> Void) {
        var request = URLRequest(url: Endpoints.getPublicUserData(userId).url)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if error != nil {
                print("user error:", error?.localizedDescription ?? "error")
                return
            }
            
            guard let data = data else {
                print("user data error")
               completion(nil, error)
               return
            }
            print("user succeeded")
            let range = (5..<data.count)
            let newData = data.subdata(in: range)
            print(String(data: newData, encoding: .utf8)!)
            
            do {
                print("decoding user")
                let decoder = JSONDecoder()
                let responseObject = try decoder.decode(UserData.self, from: newData)
                completion(responseObject, nil)
                print("user decoding succeeded")
            } catch {
               completion(nil, error)
                print("user decoding failed")
            }
        }
       task.resume()
        print("user ran")
    }
    
    //MARK: POST Requests
    
    class func login(username: String, password: String, completion: @escaping (_ success: Bool, Error?) -> Void) {
        var request = URLRequest(url: Endpoints.login.url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = "{\"udacity\": {\"username\": \"\(username)\", \"password\": \"\(password)\"}}".data(using: .utf8)
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if error != nil {
                completion(false, error)
                return
            }
            guard let data = data else {
                completion(false, error)
                return
            }
            
            let range = (5..<data.count)
            let newData = data.subdata(in: range)
            print(String(data: newData, encoding: .utf8)!)
            do {
                let decoder = JSONDecoder()
                let responseObject = try decoder.decode(LoginResponse.self, from: newData)
                let userId = responseObject.account.key
                Data.Auth.userId = userId
                completion(true, nil)
            } catch  {
                completion(false, error)
            }
        }
        task.resume()
    }
    
    class func createStudentLocation(completion: @escaping (_ success: Bool, Error?) -> Void) {
        var request = URLRequest(url: Endpoints.createStudentLocation.url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let body = "{\"firstName\": \"\(Data.User.firstName)\", \"lastName\": \"\(Data.User.lastName)\",\"mapString\": \"\(Data.User.mapString)\", \"mediaURL\": \"\(Data.User.mediaURL)\",\"latitude\": \(Data.User.latitude), \"longitude\": \(Data.User.longitude)}".data(using: .utf8)
        request.httpBody = try! JSONEncoder().encode(body)

        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            guard let data = data  else {
                completion(false, error)
                return
            }
            
            if error != nil {
                completion(false, error)
                return
            }

            do {
                let decoder = JSONDecoder()
                let responseObject = try decoder.decode(CreateLocationResponse.self, from: data)
                Data.Auth.objectId = responseObject.objectId
                completion(true, nil)
            } catch  {
                completion(false, error)
            }
        }
        task.resume()
    }
    
    // MARK: PUT Requests
    
    class func updateStudentLocation(student: PinData, objectId: String, completion: @escaping (_ success: Bool, Error?) -> Void) {
        var request = URLRequest(url: Endpoints.updateStudentLocation(objectId).url)
        request.httpMethod = "PUT"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = "{\"firstName\": \"\(student.firstName)\", \"lastName\": \"\(student.lastName)\",\"mapString\": \"\(student.mapString)\", \"mediaURL\": \"\(student.mediaURL)\",\"latitude\": \(student.latitude), \"longitude\": \(student.longitude)}".data(using: .utf8)
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if error != nil {
                completion(false, error)
                return
            }
            print(String(data: data!, encoding: .utf8)!)
        }
        task.resume()
    }
    
    //MARK: DELETE requests
    
    class func logout(completion: @escaping (_ success: Bool, Error?) -> Void) {
        var request = URLRequest(url: Endpoints.logout.url)
        request.httpMethod = "DELETE"
        var xsrfCookie: HTTPCookie? = nil
        let sharedCookieStorage = HTTPCookieStorage.shared
        for cookie in sharedCookieStorage.cookies! {
          if cookie.name == "XSRF-TOKEN" { xsrfCookie = cookie }
        }
        if let xsrfCookie = xsrfCookie {
          request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
        }
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if error != nil {
               completion(false, error)
               return
            }
            Data.Auth.objectId = ""
            Data.Auth.userId = ""
            completion(true, nil)
        }
       task.resume()
    }
}
